import { App as Application } from 'vue'

const config = {}

export let VueInstance: Application

export { config as default }

export const setVueInstance = (instance: Application): void => {
  VueInstance = instance
}
