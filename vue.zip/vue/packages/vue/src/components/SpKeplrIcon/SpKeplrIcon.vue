<template>
  <svg
    width="48"
    height="49"
    viewBox="0 0 48 49"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style="margin-bottom: 1rem"
  >
    <path
      d="M44.16 0.5H3.84C1.71923 0.5 0 2.21923 0 4.34V44.66C0 46.7808 1.71923 48.5 3.84 48.5H44.16C46.2808 48.5 48 46.7808 48 44.66V4.34C48 2.21923 46.2808 0.5 44.16 0.5Z"
      fill="url(#paint0_radial_463_11054)"
    />
    <path
      d="M44.16 0.5H3.84C1.71923 0.5 0 2.21923 0 4.34V44.66C0 46.7808 1.71923 48.5 3.84 48.5H44.16C46.2808 48.5 48 46.7808 48 44.66V4.34C48 2.21923 46.2808 0.5 44.16 0.5Z"
      fill="url(#paint1_radial_463_11054)"
      fill-opacity="0.57"
    />
    <path
      d="M44.16 0.5H3.84C1.71923 0.5 0 2.21923 0 4.34V44.66C0 46.7808 1.71923 48.5 3.84 48.5H44.16C46.2808 48.5 48 46.7808 48 44.66V4.34C48 2.21923 46.2808 0.5 44.16 0.5Z"
      fill="url(#paint2_radial_463_11054)"
      fill-opacity="0.68"
    />
    <path
      d="M44.16 0.5H3.84C1.71923 0.5 0 2.21923 0 4.34V44.66C0 46.7808 1.71923 48.5 3.84 48.5H44.16C46.2808 48.5 48 46.7808 48 44.66V4.34C48 2.21923 46.2808 0.5 44.16 0.5Z"
      fill="url(#paint3_radial_463_11054)"
      fill-opacity="0.08"
    />
    <path
      d="M44.16 0.5H3.84C1.71923 0.5 0 2.21923 0 4.34V44.66C0 46.7808 1.71923 48.5 3.84 48.5H44.16C46.2808 48.5 48 46.7808 48 44.66V4.34C48 2.21923 46.2808 0.5 44.16 0.5Z"
      fill="url(#paint4_linear_463_11054)"
      fill-opacity="0.03"
    />
    <path
      d="M16.896 41.3002V26.4202L30.96 41.3002H38.784V40.9162L22.608 23.9722L37.536 7.8922V7.7002H29.664L16.896 21.9082V7.7002H10.56V41.3002H16.896Z"
      fill="white"
    />
    <defs>
      <radialGradient
        id="paint0_radial_463_11054"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(-37.1557 23.4718) rotate(140.172) scale(82.5605 99.6279)"
      >
        <stop stop-color="#2F80F2" />
        <stop offset="0.999657" stop-color="#A942B5" />
      </radialGradient>
      <radialGradient
        id="paint1_radial_463_11054"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(-0.777489 1.2476) rotate(46.3208) scale(76.3717 80.0265)"
      >
        <stop stop-color="#45F9DE" />
        <stop offset="1" stop-color="#A942B5" stop-opacity="0" />
      </radialGradient>
      <radialGradient
        id="paint2_radial_463_11054"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(-47.52 -23.8545) rotate(180) scale(46.101 23.7402)"
      >
        <stop stop-color="#E957C5" />
        <stop offset="1" stop-color="#A942B5" stop-opacity="0" />
      </radialGradient>
      <radialGradient
        id="paint3_radial_463_11054"
        cx="0"
        cy="0"
        r="1"
        gradientUnits="userSpaceOnUse"
        gradientTransform="translate(-42.8213 3.44693) rotate(119.938) scale(27.6729 41.487)"
      >
        <stop stop-opacity="0.184878" />
        <stop offset="1" stop-color="#101010" />
      </radialGradient>
      <linearGradient
        id="paint4_linear_463_11054"
        x1="45.234"
        y1="28.8037"
        x2="0"
        y2="0.5"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="white" stop-opacity="0.184878" />
        <stop offset="1" stop-color="white" />
      </linearGradient>
    </defs>
  </svg>
</template>
<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'SpKeplrIcon'
})
</script>
