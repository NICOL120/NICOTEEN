<template>
  <svg
    width="10"
    height="10"
    viewBox="0 0 10 10"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1.79119 9.07955L8.3821 2.47727L8.37074 7.56818H9.60938V0.363636H2.41619L2.40483 1.59091H7.49574L0.90483 8.19318L1.79119 9.07955Z"
      fill="black"
    />
  </svg>
</template>
<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'SpExternalArrow'
})
</script>
